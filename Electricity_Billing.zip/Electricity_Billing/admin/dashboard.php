<?php
session_start();
require_once '../config/database.php';

// Check if admin is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'admin') {
    header("Location: ../login.php");
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Get total users count
$query = "SELECT COUNT(*) as total_users FROM users";
$stmt = $db->query($query);
$total_users = $stmt->fetch(PDO::FETCH_ASSOC)['total_users'];

// Get total bills count
$query = "SELECT COUNT(*) as total_bills FROM bills";
$stmt = $db->query($query);
$total_bills = $stmt->fetch(PDO::FETCH_ASSOC)['total_bills'];

// Get recent bills
$query = "SELECT b.*, u.full_name, mr.units_consumed 
          FROM bills b 
          JOIN users u ON b.user_id = u.user_id 
          JOIN meter_readings mr ON b.reading_id = mr.reading_id 
          ORDER BY b.bill_date DESC 
          LIMIT 10";
$stmt = $db->query($query);
$recent_bills = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Electricity Billing System</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        body {
            background: url('https://cdn.britannica.com/12/156712-131-8E29225D/transmission-lines-electricity-countryside-power-plants-homes.jpg') no-repeat center center fixed;
            background-size: cover;
        }
        .dashboard {
            display: flex;
            gap: 40px;
            justify-content: center;
            margin-top: 30px;
        }
        .card {
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 16px rgba(0,0,0,0.07);
            padding: 30px 40px;
            min-width: 250px;
            min-height: 320px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        .card h3 {
            margin-bottom: 19px;
            font-size: 1.3em;
        }
        .card table {
            width: 60%;
            border-collapse: collapse;
        }
        .card table th, .card table td {
            padding: 10px 12px;
            text-align: left;
        }
        .card table th {
            background:rgb(113, 111, 113);
        }
        .card table tr:not(:last-child) {
            border-bottom: 1px solid #eee;
        }
        .card p {
            margin: 18px 0 0 0;
            font-size: 1.1em;
            text-align: center;
        }
        .card.recent-bills {
            flex-basis: 600px;
            max-width: 700px;
            min-width: 400px;
        }
        @media (max-width: 900px) {
            .dashboard {
                flex-direction: column;
                gap: 20px;
                align-items: center;
            }
            .card {
                min-width: 90%;
                width: 100%;
                box-sizing: border-box;
            }
            .card.recent-bills {
                min-width: 90%;
                max-width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="nav">
        <a href="dashboard.php">Dashboard</a>
        <a href="users.php">Manage Users</a>
        <a href="bills.php">Manage Bills</a>
        <a href="rates.php">Manage Rates</a>
        <a href="view_complaints.php">View Complaints</a>
        <a href="../logout.php">Logout</a>
        <div class="dropdown" style="display:inline-block; position:relative;">
            <a href="#" class="dropdown-toggle" style="color:#fff; padding-left:20px;">Quick Actions ▼</a>
            <div class="dropdown-menu" style="display:none; position:absolute; background:#333; min-width:180px; z-index:1000; box-shadow:0 2px 8px rgba(0,0,0,0.15);">
                <a href="add_user.php" style="color:#fff; display:block; padding:10px 20px; text-decoration:none;">Add New User</a>
                <a href="add_bill.php" style="color:#fff; display:block; padding:10px 20px; text-decoration:none;">Generate New Bill</a>
            </div>
        </div>
    </div>
    <div style="margin: 20px 0 0 30px;"><a href="view_complaints.php" class="btn" style="display: inline-block;">View Complaints</a></div>

    <div class="container">
        <h2>Admin Dashboard</h2>
        
        <div class="dashboard">
            <div class="card">
                <h3>Statistics</h3>
                <p>Total Users: <?php echo $total_users; ?></p>
                <p>Total Bills: <?php echo $total_bills; ?></p>
            </div>
            
            <div class="card recent-bills">
                <h3>Recent Bills</h3>
                <?php if (count($recent_bills) > 0): ?>
                    <table>
                        <thead>
                            <tr>
                                <th>User</th>
                                <th>Bill Date</th>
                                <th>Units</th>
                                <th>Amount</th>
                                <th>Status</th>
                                <th>Due Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recent_bills as $bill): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($bill['full_name']); ?></td>
                                    <td><?php echo date('Y-m-d', strtotime($bill['bill_date'])); ?></td>
                                    <td><?php echo $bill['units_consumed']; ?></td>
                                    <td>₹<?php echo number_format($bill['amount'], 2); ?></td>
                                    <td><?php echo ucfirst($bill['status']); ?></td>
                                    <td><?php echo date('Y-m-d', strtotime($bill['due_date'])); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>No bills found.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        // Simple dropdown functionality
        document.querySelectorAll('.dropdown-toggle').forEach(function(toggle) {
            toggle.addEventListener('mouseover', function() {
                this.nextElementSibling.style.display = 'block';
            });
            toggle.parentElement.addEventListener('mouseleave', function() {
                this.querySelector('.dropdown-menu').style.display = 'none';
            });
        });
    </script>
</body>
</html> 