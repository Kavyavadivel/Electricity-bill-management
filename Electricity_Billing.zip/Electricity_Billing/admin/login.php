body {
    background: url('https://cdn.britannica.com/12/156712-131-8E29225D/transmission-lines-electricity-countryside-power-plants-homes.jpg') no-repeat center center fixed;
    background-size: cover;
    position: relative;
} 